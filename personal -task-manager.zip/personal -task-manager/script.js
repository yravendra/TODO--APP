
const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");
const searchInput = document.getElementById("searchInput");
const emptyMessage = document.getElementById("emptyMessage");

const totalCount = document.getElementById("totalCount");
const completedCount = document.getElementById("completedCount");
const pendingCount = document.getElementById("pendingCount");
const taskLabel = document.getElementById("taskLabel");
const themeBtn = document.getElementById("themeBtn");

const filterButtons = document.querySelectorAll(".filter-btn");

// Load saved data from localStorage
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
let currentFilter = "all";
let searchTerm = "";

// Save tasks in the browser
function saveTasks() {
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Add a new task
function addTask(text) {
    const task = {
        id: crypto.randomUUID(),
        text: text,
        completed: false
    };

    tasks.push(task);
    saveTasks();
    renderTasks();
}

// Delete a task
function deleteTask(id) {
    tasks = tasks.filter(task => task.id !== id);
    saveTasks();
    renderTasks();
}

// Mark a task completed or pending
function toggleTask(id) {
    tasks = tasks.map(task => {
        if (task.id === id) {
            return {
                ...task,
                completed: !task.completed
            };
        }

        return task;
    });

    saveTasks();
    renderTasks();
}

// Update statistics
function updateStats() {
    const completed = tasks.filter(task => task.completed).length;
    const pending = tasks.length - completed;

    totalCount.textContent = tasks.length;
    completedCount.textContent = completed;
    pendingCount.textContent = pending;

    taskLabel.textContent =
        `${tasks.length} ${tasks.length === 1 ? "task" : "tasks"}`;
}

// Render the task list
function renderTasks() {
    taskList.replaceChildren();

    const filteredTasks = tasks.filter(task => {
        const matchesFilter =
            currentFilter === "all" ||
            (currentFilter === "completed" && task.completed) ||
            (currentFilter === "pending" && !task.completed);

        const matchesSearch = task.text
            .toLowerCase()
            .includes(searchTerm.toLowerCase());

        return matchesFilter && matchesSearch;
    });

    filteredTasks.forEach(task => {
        const li = document.createElement("li");
        li.className = "task-item";

        if (task.completed) {
            li.classList.add("completed");
        }

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.className = "task-check";
        checkbox.checked = task.completed;
        checkbox.setAttribute(
            "aria-label",
            `Mark ${task.text} as completed`
        );

        checkbox.addEventListener("change", () => {
            toggleTask(task.id);
        });

        const span = document.createElement("span");
        span.className = "task-text";
        span.textContent = task.text;

        const deleteBtn = document.createElement("button");
        deleteBtn.className = "delete-btn";
        deleteBtn.type = "button";
        deleteBtn.textContent = "Delete";
        deleteBtn.setAttribute("aria-label", `Delete ${task.text}`);

        deleteBtn.addEventListener("click", () => {
            deleteTask(task.id);
        });

        li.append(checkbox, span, deleteBtn);
        taskList.appendChild(li);
    });

    emptyMessage.hidden = filteredTasks.length > 0;

    if (filteredTasks.length === 0) {
        if (tasks.length === 0) {
            emptyMessage.textContent =
                "No tasks yet. Add your first task above!";
        } else if (searchTerm) {
            emptyMessage.textContent = "No matching tasks found.";
        } else {
            emptyMessage.textContent =
                "No tasks in this filter. Try another one!";
        }
    }

    updateStats();
}

// Handle form submission
taskForm.addEventListener("submit", event => {
    event.preventDefault();

    const text = taskInput.value.trim();

    if (text === "") {
        return;
    }

    addTask(text);
    taskInput.value = "";
    taskInput.focus();
});

// Filter buttons
filterButtons.forEach(button => {
    button.addEventListener("click", () => {
        currentFilter = button.dataset.filter;

        filterButtons.forEach(btn => {
            btn.classList.toggle("active", btn === button);
        });

        renderTasks();
    });
});

// Search tasks
searchInput.addEventListener("input", () => {
    searchTerm = searchInput.value.trim();
    renderTasks();
});

// Dark / Light mode
let isDark = localStorage.getItem("theme") === "dark";

function applyTheme() {
    document.body.classList.toggle("dark", isDark);
    themeBtn.textContent = isDark ? "☀️ Light" : "🌙 Dark";
    localStorage.setItem("theme", isDark ? "dark" : "light");
}

themeBtn.addEventListener("click", () => {
    isDark = !isDark;
    applyTheme();
});

// Initial page setup
applyTheme();
renderTasks();
